* #### Compile with -> clang++ -Wall *cpp -o output -std=c++11
* #### Run with command -> ./output [inputFile].txt [numEmp]